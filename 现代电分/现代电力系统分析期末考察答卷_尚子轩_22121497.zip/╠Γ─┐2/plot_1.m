% 设置绘图曲线的宽度
lw=2;

% 设置绘图的字体大小
ft=10.5; % FontSize

% 声明一个新figure
figure();
% tiledlayout(2,1)
ax1=nexttile;

plot(t,wm1,'LineWidth',lw);
hold on
plot(t,wm2,'LineWidth',lw);
figure();
ax2=nexttile;
plot(t,dw1,'LineWidth',lw);
hold on
plot(t,dw2,'LineWidth',lw);
hold off
% 设置x轴范围和标注
xlabel(ax1,'\fontname{宋体}仿真时间\fontname{times new roman}(s)','FontSize',ft);
ylabel(ax1,'\fontname{宋体}发电机转子转速\fontname{times new roman}(pu)','FontSize',ft);
legend(ax1,"\fontname{宋体}未加入换相序技术\fontname{times new roman}","\fontname{宋体}加入换相序技术\fontname{times new roman}")
xlim(ax1,[0 1])
ylim(ax1,[0.985,1.08])
grid(ax1,'on');
ax1.FontSize = ft;
ax1.FontName ="times new roman";

xlabel(ax2,'\fontname{宋体}仿真时间\fontname{times new roman}(s)','FontSize',ft);
ylabel(ax2,'\fontname{宋体}发电机转子转速偏差\fontname{times new roman}(pu)','FontSize',ft);
legend(ax2,"\fontname{宋体}未加入换相序技术\fontname{times new roman}","\fontname{宋体}加入换相序技术\fontname{times new roman}")
xlim(ax2,[0 1])
ylim(ax2,[-0.02,0.08])
grid(ax2,'on');
ax2.FontSize = ft;
ax2.FontName ="times new roman";

% 设置绘图的位置500，500，大小 700宽 300高
% set(gcf,'Position',[700,50,600,600]);