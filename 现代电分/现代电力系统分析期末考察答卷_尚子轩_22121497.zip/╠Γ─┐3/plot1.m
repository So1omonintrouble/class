x=linspace(0,3,1000);
F=1+1./(x.^2)+2*1./x*cosd(84.2894-18.1949);
I=1./sqrt(F);
VR=1./sqrt(F)*1./x;
PR=1./x./F*cosd(18.1949)/0.338023;
ax1=plot(x,I,'LineWidth',lw);
hold on
ax2=plot(x,VR,'LineWidth',lw);
ax3=plot(x,PR,'LineWidth',lw);
ft=10.5;
lw=2;

legend("\fontname{times new roman}I/I_{SC}","\fontname{times new roman}P_R/P_{RMAX}","\fontname{times new roman}V_R/E_S")

xlabel('\fontname{times new roman}Z_{LN}/Z_{LD}','FontSize',ft);