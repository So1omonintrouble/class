x=linspace(0,10000,10000e3);
f1=25.8419;
f2=18.1949;
f3=0;
f4=-18.1949;
f5=-25.8419;

F1=1+1./(x.^2)+2*1./x*cosd(84.2894-f1);
VR1=1./sqrt(F1)*1./x;
PR1=1./x./F1*cosd(f1)/0.338023;

F2=1+1./(x.^2)+2*1./x*cosd(84.2894-f2);
VR2=1./sqrt(F2)*1./x;
PR2=1./x./F2*cosd(f2)/0.338023;

F3=1+1./(x.^2)+2*1./x*cosd(84.2894-f3);
VR3=1./sqrt(F3)*1./x;
PR3=1./x./F3*cosd(f3)/0.338023;

F4=1+1./(x.^2)+2*1./x*cosd(84.2894-f4);
VR4=1./sqrt(F4)*1./x;
PR4=1./x./F4*cosd(f4)/0.338023;

F5=1+1./(x.^2)+2*1./x*cosd(84.2894-f5);
VR5=1./sqrt(F5)*1./x;
PR5=1./x./F5*cosd(f5)/0.338023;

ft=10.5;
lw=2;
hold on
plot(PR1,VR1,'LineWidth',lw);
plot(PR2,VR2,'LineWidth',lw);
plot(PR3,VR3,'LineWidth',lw);
plot(PR4,VR4,'LineWidth',lw);
plot(PR5,VR5,'LineWidth',lw);
xlabel('\fontname{times new roman}P_R/P_{RMAX}','FontSize',ft);
ylabel('\fontname{times new roman}V_R/E_S','FontSize',ft);
legend("\fontname{times new roman}0.9\fontname{宋体}滞后", ...
    "\fontname{times new roman}0.95\fontname{宋体}滞后", ...
    "\fontname{times new roman}1.0", ...
    "\fontname{times new roman}0.95\fontname{宋体}超前", ...
    "\fontname{times new roman}0.9\fontname{宋体}超前")
xlim([0 3])
ylim([0,1.2])