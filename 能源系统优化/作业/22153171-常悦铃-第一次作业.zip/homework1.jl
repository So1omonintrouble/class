using JuMP,LinearAlgebra,MosekTools
#商品数
k=2
#节点 商品1 商品2
bus=[10 0
     -10 0
     0 0
     0 0
     0 20
     0 -20]
#支路 起点 终点 c u
branch=[
   1 2 1 5
   1 3 5 30
   3 4 1 10
   4 2 5 30
   4 6 1 30
   5 3 1 30
   5 6 5 30]
c=[branch[:,3] branch[:,3]]
u=branch[:,4]
n=size(bus,1)#节点数
m=size(branch,1)#支路数
model=Model(Mosek.Optimizer)
@variable(model,f[1:m,1:k]>=0)
@objective(model,Min,sum(c.*f))
@constraint(model,[i in 1:n,k in 1:K],sum(f[j,k] for j in findall(branch[:,1].==i))-sum(f[j,k] for j in findall(branch[:,2].==i))==bus[i,k] )
@constraint(model,[i in 1:m],sum(f[i,:])<=u[i])
optimize!(model)
println(termination_status(model))
println(objective_value(model))
println(value.(f))
