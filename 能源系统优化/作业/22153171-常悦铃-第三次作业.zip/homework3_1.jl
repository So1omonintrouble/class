using JuMP,LinearAlgebra,MosekTools

model=Model(Mosek.Optimizer)
@variable(model,x[1:2])
@variable(model,t)

@objective(model,Min,sum(x)+t)

@constraint(model,[t,x[1]-1.25,x[2]-1.25] in SecondOrderCone())
@constraint(model,[[7 8]x+[9];[1 2;3 4]x+[5;6]] in SecondOrderCone())
@constraint(model,2x[1]+t<=1)

optimize!(model)
println("第一问答案")
println("目标函数值：",objective_value(model))
println("x=",value.(x))
println("t=",value.(t))
##(2)将原问题转化为如下的二阶锥规划
model2=Model(Mosek.Optimizer)
@variable(model2,x[1:2])
@variable(model2,t)

@objective(model2,Min,x[1]+2x[2]+t)

@constraint(model2,[1,x[1],2x[2]] in SecondOrderCone())
@constraint(model2,[x[1]+x[2],t,x[1]-x[2]] in SecondOrderCone())
@constraint(model2,x[1]+t<=1)

optimize!(model2)
println("第二问答案")
println("目标函数值：",objective_value(model2))
println("x=",value.(x))
println("t=",value.(t))
