using JuMP, MosekTools
# 原问题
primal_model = Model(Mosek.Optimizer)
# 变量
@variable(primal_model,x1<=0)
@variable(primal_model,x2>=0)
@variable(primal_model,x3>=0)
@variable(primal_model,x4)
# 目标函数
@objective(primal_model,Min,x1-4x2)
# 约束条件
@constraint(primal_model,2x1+3x2-x3+x4<=0)
@constraint(primal_model,x1+2x2+3x3+4x4>=4)
@constraint(primal_model,-x1-x2+2x3+x4==6)
# 打印优化模型
print(primal_model)
# 求解优化模型
optimize!(primal_model)
# 输出求解结果
# 求解状态
println("程序终止状态：", termination_status(primal_model))
println("原问题状态：", primal_status(primal_model))
println("对偶问题状态：", dual_status(primal_model))
# 目标函数值和变量值
println("原问题目标函数值：", objective_value(primal_model))
println("x1=", value(x1))
println("x2=", value(x2))
println("x3=", value(x3))
println("x4=", value(x4))

# 建立对偶问题
dual_model = Model(Mosek.Optimizer)
# 对偶变量
@variable(dual_model,p1<=0)
@variable(dual_model,p2>=0)
@variable(dual_model,p3)
# 优化目标
@objective(dual_model,Max,4p2+6p3)
# 约束条件
@constraint(dual_model,2p1+p2-p3>=1)
@constraint(dual_model,3p1+2p2-p3<=-4)
@constraint(dual_model,-p1+3p2+2p3<=0)
@constraint(dual_model,p1+4p2+p3==0)
# 打印对偶模型
print(dual_model)
# 求解对偶问题
optimize!(dual_model)
# 值
println("对偶问题目标函数值：", objective_value(dual_model))
println("p1=", value(p1))
println("p2=", value(p2))
println("p3=",value(p3))

# 验证
C=[1;-4;0;0]
A=[
    2  3 -1 1;
    1  2  3 4;
    -1 -1 2 1;
]
B=[0;4;6]
X=[x1 ;x2 ;x3 ;x4 ]
P=[p1 ;p2 ;p3 ]
A1=[2 3 -1 1]
A2=[1 2 3 4]
A3=[-1 -1 2 1]
A4=[2;1;-1]
A5=[3;2;-1]
A6=[-1;3;2]
A7=[1;4;1]
C1=1;C2=-4;C3=0;C4=0
B1=0;B2=4;B3=6

println("验证对偶定理：",value(P'*B)-value(C'*X))
