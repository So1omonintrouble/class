using JuMP, MosekTools
# 创建模型
lmp_model = Model(Mosek.Optimizer)

# 变量g和l分别表示发电机和线路功率
@variable(lmp_model,g1>=0)
@variable(lmp_model,g2>=0)
@variable(lmp_model,g3>=0)
@variable(lmp_model,l1)
@variable(lmp_model,l2)
@variable(lmp_model,l3)
@variable(lmp_model,l4)
@variable(lmp_model,l5)
@variable(lmp_model,l6)
@variable(lmp_model,l7)
@variable(lmp_model,l8)
@variable(lmp_model,l9)

# 优化目标为最小化总购电成本
@objective(lmp_model,Min,200g1+300g2+250g3)

# 约束条件
# 节点功率平衡约束
@constraint(lmp_model,pb1,g1-l1==0)
@constraint(lmp_model,pb2,g2-l4==0)
@constraint(lmp_model,pb3,g3-l9==0)
@constraint(lmp_model,pb4,l9-l7-l8==0)
@constraint(lmp_model,pb5,l5+l7==400)
@constraint(lmp_model,pb6,l1-l2-l5==0)
@constraint(lmp_model,pb7,l2-l3==300)
@constraint(lmp_model,pb8,l4+l3+l6==0)
@constraint(lmp_model,pb9,l8-l6==400)

# 线路容量约束
@constraint(lmp_model,l1c_max,l1<=600)
@constraint(lmp_model,l1c_min,l1>=-600)

@constraint(lmp_model,l2c_max,l2<=400)
@constraint(lmp_model,l2c_min,l2>=-400)

@constraint(lmp_model,l3c_max,l3<=700)
@constraint(lmp_model,l3c_min,l3>=-700)

@constraint(lmp_model,l4c_max,l4<=700)
@constraint(lmp_model,l4c_min,l4>=-700)

@constraint(lmp_model,l5c_max,l5<=400)
@constraint(lmp_model,l5c_min,l5>=-400)

@constraint(lmp_model,l6c_max,l6<=400)
@constraint(lmp_model,l6c_min,l6>=-400)

@constraint(lmp_model,l7c_max,l7<=400)
@constraint(lmp_model,l7c_min,l7>=-400)

@constraint(lmp_model,l8c_max,l8<=300)
@constraint(lmp_model,l8c_min,l8>=-300)

@constraint(lmp_model,l9c_max,l9<=800)
@constraint(lmp_model,l9c_min,l9>=-800)

# 发电机容量约束
@constraint(lmp_model,gc1,g1<=500)
@constraint(lmp_model,gc2,g2<=600)
@constraint(lmp_model,gc3,g3<=700)

# 打印优化模型
print(lmp_model)

# 求解优化模型
optimize!(lmp_model)

# 输出求解结果
# 求解状态
println("程序终止状态：", termination_status(lmp_model))
println("原问题状态：", primal_status(lmp_model))
println("对偶问题状态：", dual_status(lmp_model))

# 目标函数值和变量值
println("目标函数值：", objective_value(lmp_model))
println("发电机G1出力：", value.(g1))
println("发电机G2出力：", value.(g2))
println("发电机G3出力：", value.(g3))
println("线路1传输功率：", value.(l1))
println("线路2传输功率：", value.(l2))
println("线路3传输功率：", value.(l3))
println("线路4传输功率：", value.(l4))
println("线路5传输功率：", value.(l5))
println("线路6传输功率：", value.(l6))
println("线路7传输功率：", value.(l7))
println("线路8传输功率：", value.(l8))
println("线路9传输功率：", value.(l9))

# 对偶变量
println("是否存在对偶变量：", has_duals(lmp_model))
println("节点1功率平衡约束的对偶变量值：", dual(pb1))
println("节点2功率平衡约束的对偶变量值：", dual(pb2))
println("节点3功率平衡约束的对偶变量值：", dual(pb3))
println("节点4功率平衡约束的对偶变量值：", dual(pb4))
println("负荷节点5功率平衡约束的对偶变量值：", dual(pb5))
println("节点6功率平衡约束的对偶变量值：", dual(pb6))
println("负荷节点7功率平衡约束的对偶变量值：", dual(pb7))
println("节点8功率平衡约束的对偶变量值：", dual(pb8))
println("负荷节点9功率平衡约束的对偶变量值：", dual(pb9))

println("线路1传输功率上界约束的对偶变量值：", dual(l1c_max))
println("线路1传输功率下界约束的对偶变量值：", dual(l1c_min))

println("线路2传输功率上界约束的对偶变量值：", dual(l2c_max))
println("线路2传输功率下界约束的对偶变量值：", dual(l2c_min))

println("线路3传输功率上界约束的对偶变量值：", dual(l3c_max))
println("线路3传输功率下界约束的对偶变量值：", dual(l3c_min))

println("线路4传输功率上界约束的对偶变量值：", dual(l4c_max))
println("线路4传输功率下界约束的对偶变量值：", dual(l4c_min))

println("线路5传输功率上界约束的对偶变量值：", dual(l5c_max))
println("线路5传输功率下界约束的对偶变量值：", dual(l5c_min))

println("线路6传输功率上界约束的对偶变量值：", dual(l6c_max))
println("线路6传输功率下界约束的对偶变量值：", dual(l6c_min))

println("线路7传输功率上界约束的对偶变量值：", dual(l7c_max))
println("线路7传输功率下界约束的对偶变量值：", dual(l7c_min))

println("线路8传输功率上界约束的对偶变量值：", dual(l8c_max))
println("线路8传输功率下界约束的对偶变量值：", dual(l8c_min))

println("线路9传输功率上界约束的对偶变量值：", dual(l9c_max))
println("线路9传输功率下界约束的对偶变量值：", dual(l9c_min))

println("发电机G1容量约束的对偶变量值：", dual(gc1))
println("发电机G2容量约束的对偶变量值：", dual(gc2))
println("发电机G3容量约束的对偶变量值：", dual(gc3))

# 影子价格
println("节点1功率平衡约束的影子价格：", shadow_price(pb1))
println("节点2功率平衡约束的影子价格：", shadow_price(pb2))
println("节点3功率平衡约束的影子价格：", shadow_price(pb3))
println("节点4功率平衡约束的影子价格：", shadow_price(pb4))
println("负荷节点5功率平衡约束的影子价格：", shadow_price(pb5))
println("节点6功率平衡约束的影子价格：", shadow_price(pb6))
println("负荷节点7功率平衡约束的影子价格：", shadow_price(pb7))
println("节点8功率平衡约束的影子价格：", shadow_price(pb8))
println("负荷节点9功率平衡约束的影子价格：", shadow_price(pb9))

println("线路1传输功率上界约束的影子价格：", shadow_price(l1c_max))
println("线路1传输功率下界约束的影子价格：", shadow_price(l1c_min))
println("线路2传输功率上界约束的影子价格：", shadow_price(l2c_max))
println("线路2传输功率下界约束的影子价格：", shadow_price(l2c_min))
println("线路3传输功率上界约束的影子价格：", shadow_price(l3c_max))
println("线路3传输功率下界约束的影子价格：", shadow_price(l3c_min))
println("线路4传输功率上界约束的影子价格：", shadow_price(l4c_max))
println("线路4传输功率下界约束的影子价格：", shadow_price(l4c_min))
println("线路5传输功率上界约束的影子价格：", shadow_price(l5c_max))
println("线路5传输功率下界约束的影子价格：", shadow_price(l5c_min))
println("线路6传输功率上界约束的影子价格：", shadow_price(l6c_max))
println("线路6传输功率下界约束的影子价格：", shadow_price(l6c_min))
println("线路7传输功率上界约束的影子价格：", shadow_price(l7c_max))
println("线路7传输功率下界约束的影子价格：", shadow_price(l7c_min))
println("线路8传输功率上界约束的影子价格：", shadow_price(l8c_max))
println("线路8传输功率下界约束的影子价格：", shadow_price(l8c_min))
println("线路9传输功率上界约束的影子价格：", shadow_price(l9c_max))
println("线路9传输功率下界约束的影子价格：", shadow_price(l9c_min))

println("发电机G1容量约束的影子价格：", shadow_price(gc1))
println("发电机G2容量约束的影子价格：", shadow_price(gc2))
println("发电机G3容量约束的影子价格：", shadow_price(gc3))
