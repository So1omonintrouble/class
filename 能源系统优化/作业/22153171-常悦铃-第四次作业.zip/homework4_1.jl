using JuMP,MosekTools,LinearAlgebra
A1 = [1 0 1;0 3 7;1 7 5]
A2 = [0 2 8;2 6 0;8 0 4]
C = [1 2 3;2 9 0;3 0 7]
b1 = 11
b2 = 19
model=Model(Mosek.Optimizer)
# 方法一：直接建立半定矩阵变量
@variable(model,X[1:3,1:3],PSD)

@objective(model,Min,dot(C,X))
@constraint(model,dot(A1,X)==b1)
@constraint(model,dot(A2,X)==b2)
@constraint(model,X.>=0)
print(model)
optimize!(model)
println("程序终止状态：", termination_status(model))
println("原问题状态：", primal_status(model))
println("最优值：",objective_value(model))
println("最优解：X = ",value.(X))
