Sbase=1000
Vbase=12.66
Xbase=Vbase^2*1e3/Sbase
Branch=[#序号 节点1 节点2     电阻        电抗
        1    1      2       0.493       0.2511;
        2    2      3       0.366       0.1864;
        3    3      4       0.3811      0.1941;
        4    4      5       0.819       0.707;
        5    5      6       0.1872      0.6188;
        6    6      7       0.7114      0.2351;
        7    7      8       1.03        0.74;
        8    8      9       1.044       0.74;
        9    9      10      0.1966      0.065;
        10   10     11      0.3744      0.1238;
        11   11     12      1.468       1.155;
        12   12     13      0.5416      0.7129;
        13   13     14      5.91        5.26;
        14   14     15      7.463       5.45;
        15   15     16      3.289       4.721;
        16   16     17      7.32        5.74;
        17   1      18      0.164       0.1565;
        18   18     19      1.5042      1.3554;
        19   19     20      0.4095      0.4784;
        20   20     21      0.7089      0.9373;
        21   2      22      4.512       3.083;
        22   22     23      0.898       0.7091;
        23   23     24      0.896       0.7011;
        24   5      25      0.203       0.1034;
        25   25     26      0.2842      0.1447;
        26   26     27      1.059       0.9337;
        27   27     28      0.8042      0.7006;
        28   28     29      0.5075      0.2585;
        29   29     30      0.9744      0.963;
        30   30     31      0.3105      0.3619;
        31   31     32      0.341       0.5302;
]
Node=[#序号 有功负荷 无功负荷 有功上限 无功上限
    1       100     60      800     600;
    2       90      40      0       0;
    3       120     80      570     500;
    4       60      30      0       0;
    5       60      20      0       0;
    6       200     100     510     440;
    7       200     100     0       0;
    8       60      20      0       0;
    9       60      20      0       0;
    10      45      30      0       0;
    11      60      35      0       0;
    12      60      35      0       0;
    13      120     80      0       0;
    14      60      10      420     380;
    15      60      20      0       0;
    16      60      20      0       0;
    17      90      40      0       0;
    18      90      40      0       0;
    19      90      40      0       0;
    20      90      40      380     340;
    21      90      40      0       0;
    22      90      50      0       0;
    23      420     200     0       0;
    24      420     200     600     500;
    25      60      25      0       0;
    26      60      25      0       0;
    27      60      20      400     320;
    28      120     10      0       0;
    29      200     600     0       0;
    30      150     70      0       0;
    31      210     100     490     450;
    32      60      40      0       0;
    ]
(m,nons)=size(Branch)
(n,nons)=size(Node)
A1=zeros(n,m)
A2=zeros(n,m)
for i=1:n
    for j=1:m
        if Branch[j,2]==i
            A1[i,j]=1
        end
        if Branch[j,3]==i
            A2[i,j]=-1
        end
    end
end
Pgmax=Node[:,4]/Sbase
Qgmax=Node[:,5]/Sbase
Pl=Node[:,2]/Sbase
Ql=Node[:,3]/Sbase
R=Branch[:,4]/Xbase
X=Branch[:,5]/Xbase
@time begin
using Convex,SCS,LinearAlgebra
V =Variable(n)
I =Variable(m)
P =Variable(m)
Q =Variable(m)
Pg=Variable(n)
Qg=Variable(n)
opf=minimize(sum(Pg))
opf.constraints += V<=1.21
opf.constraints += V>=0.81
opf.constraints += I<=1
opf.constraints += I>=0
opf.constraints += Pg<=Pgmax
opf.constraints += Qg<=Qgmax
opf.constraints += Pg>=0
opf.constraints += Qg>=0
opf.constraints += A1*P-(Pg-Pl)+A2*(P-I.*R)==0
opf.constraints += A1*Q-(Qg-Ql)+A2*(Q-I.*X)==0
opf.constraints += (A1+A2)'*V-2(P.*R+Q.*X)-I.*(R.*R+X.*X)==0
for i=1:m
    A=[2P[i];2Q[i];V[Branch[i,2]]-I[i]]
    opf.constraints += norm(A)<=V[Branch[i,2]]+I[i]
end
solve!(opf,SCS.Optimizer)
println(opf.status)
println(opf.optval)
end
