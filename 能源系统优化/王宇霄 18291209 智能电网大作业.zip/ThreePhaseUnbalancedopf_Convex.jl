Sbase=1000
Vbase=4.16/sqrt(3)
Xbase=Vbase^2*1e3/Sbase
Ibase=Sbase/4.16

#       节点 A有功 A无功 B有功 B无功 C有功 C无功 发电机有功 发电机无功
Bus=[

        1  0      0      0      0    0      0       9999   9999;
        2  8.5    5      33     19   58.5   34      0   0;
        3  0      0      0      0    0      0       0   0;
        4  160    110    120    90   120    90      500 400;
        5  434.91 349.57 418    239  572.09 280.43  500 400;
        6  485    190    68     60   290    212     0   0;
        7  0      0      0      0    0      0       0   0;
        8  0      0      170    125  0      0       500 400;
        9  0      0      153.11 -0.4 76.89  132.4   0   0;
        10 0      0      0      0    0      0       0   0;
        11 128    86     0      0    0      0       560 550;
        12 0      0      0      0    170    80      0   0;
    ]

#支路矩阵，其中3-4支路修改，暂时不会处理变压器
# 首端节点 末端节点 距离 型号
Branch=[
        1  2  2000/5280 1;
        2  8  500/5280  3;
        2  3  500/5280  2;
        2  5  2000/5280 1;
        3  4  800/5280  4;
        5  10 300/5280  4;
        5  6  500/5280  6;
        5  7  1000/5280 1;
        8  9  300/5280  3;
        10 11 800/5280  7;
        10 12 300/5280  5;
    ]

#读取系统的节点数和支路数
(n,non)=size(Bus)
(m,non)=size(Branch)

#输入各种线路类型的阻抗数据
z601=[
        0.3465+1.0179im 0.1560+0.5017im 0.1508+0.4236im;
        0.1560+0.5017im 0.3375+1.0478im 0.1535+0.3849im;
        0.1580+0.4236im 0.1535+0.3849im 0.3414+1.0348im
    ]
z602=[
        0.7526+1.1814im 0.1580+0.4236im 0.1560+0.5017im;
        0.1580+0.4236im 0.7475+1.1983im 0.1535+0.3849im;
        0.1560+0.5017im 0.1535+0.3849im 0.7436+1.2112im
    ]
z603=[
        0.0000+0.0000im 0.0000+0.0000im 0.0000+0.0000im;
        0.0000+0.0000im 1.3294+1.3471im 0.2066+0.4591im;
        0.0000+0.0000im 0.2066+0.4591im 1.3238+1.3569im
    ]
z604=[
        1.3238+1.3569im 0.0000+0.0000im 0.2066+0.4591im;
        0.0000+0.0000im 0.0000+0.0000im 0.0000+0.0000im;
        0.2066+0.4591im 0.0000+0.0000im 1.3294+1.3471im;
    ]
z605=[
        0.0000+0.0000im 0.0000+0.0000im 0.0000+0.0000im;
        0.0000+0.0000im 0.0000+0.0000im 0.0000+0.0000im;
        0.0000+0.0000im 0.0000+0.0000im 1.3292+1.3475im
]
z606=[
        0.7982+0.4463im 0.3192+0.0328im 0.2849-0.0143im;
        0.3192+0.0328im 0.7891+0.4041im 0.3192+0.0328im;
        0.2849-0.0143im 0.3192+0.0328im 0.7982+0.4463im
    ]
z607=[
        1.3425+0.5124im 0.0000+0.0000im 0.0000+0.0000im;
        0.0000+0.0000im 0.0000+0.0000im 0.0000+0.0000im;
        0.0000+0.0000im 0.0000+0.0000im 0.0000+0.0000im
    ]

#定义三维矩阵z，保存每个支路类型的阻抗信息
z=zeros(Complex{Float64},3,3,7)
z[:,:, 1]=z601/Xbase
z[:,:, 2]=z602/Xbase
z[:,:, 3]=z603/Xbase
z[:,:, 4]=z604/Xbase
z[:,:, 5]=z605/Xbase
z[:,:, 6]=z606/Xbase
z[:,:, 7]=z607/Xbase

#定义每个发电机出力上限
Pgmax=zeros(n,1)
Qgmax=zeros(n,1)
Pgmax=Bus[:,8]/Sbase
Qgmax=Bus[:,9]/Sbase

#定义三相负荷
SAl=Bus[:,2]/Sbase+Bus[:,3]/Sbase*1im
SBl=Bus[:,4]/Sbase+Bus[:,5]/Sbase*1im
SCl=Bus[:,6]/Sbase+Bus[:,7]/Sbase*1im
Sl=zeros(Complex{Float64},3,1,n)
for i=1:n
    Sl[:,:,i]=[SAl[i];SBl[i];SCl[i]]  #负荷矩阵
end

#定义参考节点的电压
v0=[1;-0.5-sqrt(3)/2*1im;-0.5+sqrt(3)/2*1im]
Vref=v0*v0'
@time begin
#建模，调用Convex和求解器SCS
using Convex,SCS,LinearAlgebra
#定义变量，Sg为发电机出力，S为节点流出功率，V为节点电压的平方，I为支路电流的平方
Sg=[ComplexVariable(3,1) for i in 1:n]
S =[ComplexVariable(3,3) for i in 1:m]
V =[HermitianSemidefinite(3,3) for i in 1:n]
I =[HermitianSemidefinite(3,3) for i in 1:m]

#目标函数为发电机有功出力最小
opf = minimize(sum(real(sum(Sg[:,:,:]))))

#节点功率平衡约束
for i=1:n
    Sout=0
    Sin =0
    for j=1:m
        if Branch[j,1]==i
            Sout=Sout+diag(S[j])
        end
        if Branch[j,2]==i
            Sin=Sin+diag(S[j]-z[:,:,Int(Branch[j,4])]*Branch[j,3]*I[j])
        end
    end
opf.constraints += Sout-Sin-(Sg[i]-Sl[:,:,i])==0
end

#发电机出力约束
for i=1:n
    opf.constraints += real(sum(Sg[i]))<=Pgmax[i]
    opf.constraints += imag(sum(Sg[i]))<=Qgmax[i]
    opf.constraints += real(Sg[i])>=0
    opf.constraints += imag(Sg[i])>=0
end

#节点电压波动约束
for i=1:n
    opf.constraints += diag(real(V[i])) >= 0.9025
    opf.constraints += diag(real(V[i])) <= 1.1025
end

#支路电流约束
for i=1:m
    opf.constraints += diag(real(I[i])) >= 0
    opf.constraints += diag(real(I[i])) <= (200/Ibase)^2
end

#参考节点电压约束
opf.constraints += V[1]==Vref

#节点电压平衡约束
for i=1:m
    opf.constraints += V[Int(Branch[i,1])]-V[Int(Branch[i,2])]-S[i]*(z[:,:,Int(Branch[i,4])]*Branch[i,3])'-(z[:,:,Int(Branch[i,4])]*Branch[i,3])*S[i]'+(z[:,:,Int(Branch[i,4])]*Branch[i,3])*I[i]*(z[:,:,Int(Branch[i,4])]*Branch[i,3])'==0
end

#SDP约束
for i=1:m
    opf.constraints += [V[Int(Branch[i,1])] S[i] ; S[i]' I[i]] in :SDP
end
solve!(opf,SCS.Optimizer)
println(opf.status)
println(opf.optval)
end
